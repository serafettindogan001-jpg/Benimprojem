/**
 * Wingman App – Frontend Logic
 * Mock AI responses follow the product principles defined in the system prompt.
 */

// ---------- Navigation ----------
function showScreen(id) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const target = document.getElementById(id);
  if (target) target.classList.add('active');
  window.scrollTo(0, 0);
}

document.querySelectorAll('.back-btn').forEach(btn => {
  btn.addEventListener('click', () => showScreen(btn.dataset.target));
});

document.getElementById('btn-first-message').addEventListener('click', () => {
  showScreen('first-message-screen');
  resetFirstMessage();
});

document.getElementById('btn-continue-chat').addEventListener('click', () => {
  showScreen('continue-screen');
  resetContinue();
});

// ---------- Toast ----------
function showToast(msg = 'Kopyalandı') {
  const toast = document.getElementById('toast');
  toast.textContent = msg;
  toast.classList.remove('hidden');
  requestAnimationFrame(() => toast.classList.add('show'));
  setTimeout(() => {
    toast.classList.remove('show');
    setTimeout(() => toast.classList.add('hidden'), 250);
  }, 1800);
}

// ---------- Clipboard ----------
async function copyText(text, btn) {
  try {
    await navigator.clipboard.writeText(text);
    if (btn) {
      btn.classList.add('copied');
      setTimeout(() => btn.classList.remove('copied'), 1500);
    }
    showToast();
  } catch (e) {
    // Fallback
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
    showToast();
  }
}

// ---------- Mock AI Engine (follows Wingman principles) ----------
const STYLES = {
  soft: 'Yumuşak',
  balanced: 'Dengeli',
  assertive: 'İddialı',
  playful: 'Espri',
  direct: 'Direkt'
};

function pickStyles(mode = 'normal') {
  if (mode === 'assertive') return ['balanced', 'assertive', 'playful'];
  if (mode === 'soft') return ['soft', 'balanced', 'soft'];
  return ['soft', 'balanced', 'assertive'];
}

// Simple mock generators – in a real app these would call a vision + LLM backend
const FIRST_MESSAGE_POOL = [
  {
    soft: {
      text: 'O cafe’deki fotoğraftaki ışık gerçekten iyi yakalanmış. Orası senin mi yoksa sadece uğradığın bir yer mi?',
      reason: 'Spesifik bir gözlemle başlıyor, “baktım” demeden meraka açıyor ve cevabı kolaylaştırıyor.'
    },
    balanced: {
      text: 'O yürüyüş fotoğrafındaki enerji bambaşka. Senin için bu tarz anlar rutin mi yoksa nadir mi?',
      reason: 'Gözlem + kişiliğe dair soru. Hem iltifat hem de sohbeti ilerletecek açık kapı bırakıyor.'
    },
    assertive: {
      text: 'O gülüş fotoğrafı biraz tehlikeli. İnsanı “bu kızla tanışmak lazım” dedirtiyor.',
      reason: 'Direkt, özgüvenli ve hafif riskli. Güvenli alanın dışına çıkıp dikkat çekiyor.'
    },
    playful: {
      text: 'O fotoğraftaki kahve fincanı bana “bugün biraz yavaşlayayım” dedirtiyor. Sen de öyle mi hissediyorsun yoksa sürekli hareket mi?',
      reason: 'Nesneden yola çıkıp kişiliğe bağlayan esprili bir kanca. Basit “merhaba”dan uzak.'
    }
  },
  {
    soft: {
      text: 'Biografinde yazdığın o cümle aklıma takıldı. Gerçekten o kadar mı düşünüyorsun yoksa biraz abartı mı?',
      reason: 'Biyografiden spesifik detay alıyor, yargılamadan merak uyandırıyor.'
    },
    balanced: {
      text: 'O son paylaşımındaki mekân çok tanıdık geldi. Oraya gidenlerin ortak bir tarafı var gibi… sen de o gruptan mısın?',
      reason: 'Ortak nokta arayışı + hafif iddia. Cevap vermeyi teşvik ediyor.'
    },
    assertive: {
      text: 'Profilinde bir şey dikkatimi çekti. Çoğu kişi bunu bu kadar doğal taşıyamıyor.',
      reason: 'Belirsizlik + iltifat karışımı. “Ne?” diye sormaya zorluyor ve meraka yol açıyor.'
    },
    playful: {
      text: 'O fotoğraftaki poz “ben her şeyi kontrol ederim” enerjisi veriyor. Doğru mu okudum yoksa tamamen yanlış mı?',
      reason: 'Hafif challenge. Yanlış çıkarsa bile sohbet başlıyor, doğruysa bağ kuruyor.'
    }
  },
  {
    soft: {
      text: 'O manzara fotoğrafı gerçekten sakin hissettiriyor. Böyle yerleri mi tercih ediyorsun yoksa şehir enerjisi mi?',
      reason: 'Nötr ve güvenli açılış. Cevap eşiğini düşük tutuyor.'
    },
    balanced: {
      text: 'Son paylaşımındaki detaylar bana bir hikâye anlatıyor gibi. O anın arkasında ne vardı?',
      reason: 'Hikâye çağrısı. İnsanlar kendi hikâyelerini anlatmayı sever.'
    },
    assertive: {
      text: 'Bu profil “kolay kazanılmayacak” tipi veriyor. Yanılıyor muyum?',
      reason: 'Riskli ama çekici. Çerçeveyi yüksek tutuyor ve savunmaya geçmeden iddia atıyor.'
    },
    playful: {
      text: 'O fotoğraftaki köpek mi yoksa sen mi daha dominant görünüyorsun? Karar veremedim.',
      reason: 'Esprili pattern interrupt. Beklenmedik olduğu için akılda kalıyor.'
    }
  }
];

const CONTINUE_POOL = {
  short_reply: [
    {
      soft: { text: 'Anladım. O zaman daha sonra konuşuruz.', reason: 'Yatırımı azaltıyor, baskı kurmuyor. Kısa cevaplara kısa dönüş.' },
      balanced: { text: 'Tamamdır. İyi akşamlar.', reason: 'Temiz çıkış. “Neden yazmıyorsun” demeden saygılı kapanış.' },
      assertive: { text: 'Kısa cevaplar da bir mesaj. Anladım.', reason: 'Farkındalığı gösteriyor, drama yaratmadan çerçeveyi koruyor.' }
    }
  ],
  normal: [
    {
      soft: {
        text: 'Anladım seni. O konuda aslında şöyle düşünüyorum…',
        reason: 'Empati + kendi görüşünü ekleyerek dengeyi sağlıyor.'
      },
      balanced: {
        text: 'Bu bana ilginç geldi. Peki sen bu durumu nasıl yaşıyorsun?',
        reason: 'Merak + soru. Ama sorguyu değil, deneyimi soruyor.'
      },
      assertive: {
        text: 'Bence bu konuda en net olan kazanır. Senin netliğin nedir?',
        reason: 'İddialı çerçeve. Karşı tarafı da netleşmeye davet ediyor.'
      },
      playful: {
        text: 'Bu cevap biraz “sürpriz kutu” gibiydi. İçinden ne çıkacağını merak ettim.',
        reason: 'Hafif espriyle devam enerjisini yüksek tutuyor.'
      }
    }
  ],
  cold: [
    {
      soft: {
        text: 'Biraz ara vermişiz gibi. Keyfin yerindeyse tekrar yazışırız.',
        reason: 'Suçu yüklemeden, baskısız yeniden açılış.'
      },
      balanced: {
        text: 'Sessizlik de bir cevap. Yine de merak ettiğim bir şey vardı ama belki başka zaman.',
        reason: 'Onurlu çıkış + açık kapı. Desperate görünmüyor.'
      },
      assertive: {
        text: 'Sanırım zamanlama tutmadı. İyi günler.',
        reason: 'Kısa, net, saygılı kapanış. Çerçeveyi koruyor.'
      }
    }
  ]
};

function generateFirstMessages(variant = 'normal') {
  const pool = FIRST_MESSAGE_POOL[Math.floor(Math.random() * FIRST_MESSAGE_POOL.length)];
  const styles = pickStyles(variant);
  const tips = [
    'İlk mesajda “profiline baktım” demek artık klişe. Spesifik gözlem + merak her zaman daha güçlü.',
    'Cevap gelmezse 1 nazik takip yeter. İkinci mesaj genellikle zayıf gösterir.',
    'Uzun ilk mesajlar baskı yaratır. 1-2 cümle ideal.'
  ];
  return {
    suggestions: styles.map(s => ({
      style: STYLES[s] || s,
      text: pool[s]?.text || pool.balanced.text,
      reason: pool[s]?.reason || pool.balanced.reason
    })),
    tip: tips[Math.floor(Math.random() * tips.length)]
  };
}

function generateContinueMessages(myMsg, herMsg, variant = 'normal') {
  const herLen = (herMsg || '').trim().length;
  let category = 'normal';
  if (herLen < 12) category = 'short_reply';
  if (/ok|hı hı|iyi|tmm|tamam|hmm|evet/i.test(herMsg || '') && herLen < 20) category = 'short_reply';
  if (!herMsg || herMsg.trim() === '') category = 'cold';

  const pool = CONTINUE_POOL[category][0];
  const styles = pickStyles(variant);
  const tips = [
    'Kısa cevap aldığında yatırımı azalt. Daha az, daha kaliteli yaz.',
    'Her mesajda küçük bir açık kapı bırak. Merak sohbeti sürdürür.',
    'Randevu teklifinde “ne zaman müsaitsin” yerine somut bir teklif daha güçlüdür.'
  ];

  // Slight contextual flavor
  let base = styles.map(s => ({
    style: STYLES[s] || s,
    text: pool[s]?.text || pool.balanced?.text || 'Anladım.',
    reason: pool[s]?.reason || pool.balanced?.reason || ''
  }));

  // Make them a bit more specific if possible
  if (category === 'normal' && herMsg) {
    base[1].text = `Bu dediğin ilginç. "${herMsg.slice(0, 40)}${herMsg.length > 40 ? '…' : ''}" kısmı aklıma takıldı.`;
    base[1].reason = 'Onun söylediği bir detaya callback yapıyor. Dikkatli dinlendiğini hissettiriyor.';
  }

  return {
    suggestions: base,
    tip: tips[Math.floor(Math.random() * tips.length)]
  };
}

// ---------- Render Helpers ----------
function renderSuggestions(container, data) {
  container.innerHTML = '';
  data.suggestions.forEach((s, i) => {
    const card = document.createElement('div');
    card.className = 'suggestion-card';
    card.style.animationDelay = `${i * 0.08}s`;
    card.innerHTML = `
      <div class="suggestion-header">
        <span class="style-tag">${s.style}</span>
        <button class="copy-btn" type="button" aria-label="Kopyala" data-text="${escapeAttr(s.text)}">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <rect x="9" y="9" width="13" height="13" rx="2" ry="2"/>
            <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/>
          </svg>
        </button>
      </div>
      <p class="message-text">“${escapeHtml(s.text)}”</p>
      <p class="reason"><strong>Neden:</strong> ${escapeHtml(s.reason)}</p>
    `;
    container.appendChild(card);
  });

  // Tip
  const tip = document.createElement('div');
  tip.className = 'tip-box';
  tip.innerHTML = `<strong>İpucu:</strong> ${escapeHtml(data.tip)}`;
  container.appendChild(tip);

  // Bind copy
  container.querySelectorAll('.copy-btn').forEach(btn => {
    btn.addEventListener('click', () => copyText(btn.dataset.text, btn));
  });
}

function escapeHtml(str) {
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function escapeAttr(str) {
  return String(str).replace(/"/g, '&quot;');
}

// ---------- First Message Flow ----------
const profileUpload = document.getElementById('profile-upload');
const uploadArea = document.getElementById('upload-area');
const uploadPlaceholder = document.getElementById('upload-placeholder');
const uploadPreview = document.getElementById('upload-preview');
const previewImg = document.getElementById('preview-img');
const removePreview = document.getElementById('remove-preview');
const firstLoading = document.getElementById('first-loading');
const firstResults = document.getElementById('first-results');
const firstSuggestions = document.getElementById('first-suggestions');
const firstError = document.getElementById('first-error');

function resetFirstMessage() {
  profileUpload.value = '';
  uploadPlaceholder.classList.remove('hidden');
  uploadPreview.classList.add('hidden');
  firstLoading.classList.add('hidden');
  firstResults.classList.add('hidden');
  firstError.classList.add('hidden');
  uploadArea.classList.remove('dragover');
}

uploadPlaceholder.addEventListener('click', () => profileUpload.click());
uploadArea.addEventListener('dragover', e => {
  e.preventDefault();
  uploadArea.classList.add('dragover');
});
uploadArea.addEventListener('dragleave', () => uploadArea.classList.remove('dragover'));
uploadArea.addEventListener('drop', e => {
  e.preventDefault();
  uploadArea.classList.remove('dragover');
  if (e.dataTransfer.files?.[0]) handleProfileFile(e.dataTransfer.files[0]);
});

profileUpload.addEventListener('change', () => {
  if (profileUpload.files?.[0]) handleProfileFile(profileUpload.files[0]);
});

removePreview.addEventListener('click', resetFirstMessage);

function handleProfileFile(file) {
  if (!file.type.startsWith('image/')) {
    firstError.classList.remove('hidden');
    return;
  }
  const reader = new FileReader();
  reader.onload = e => {
    previewImg.src = e.target.result;
    uploadPlaceholder.classList.add('hidden');
    uploadPreview.classList.remove('hidden');
    firstError.classList.add('hidden');
    runFirstAnalysis('normal');
  };
  reader.readAsDataURL(file);
}

function runFirstAnalysis(variant) {
  firstResults.classList.add('hidden');
  firstLoading.classList.remove('hidden');
  // Simulate analysis delay
  setTimeout(() => {
    firstLoading.classList.add('hidden');
    const data = generateFirstMessages(variant);
    renderSuggestions(firstSuggestions, data);
    firstResults.classList.remove('hidden');
  }, 1600 + Math.random() * 800);
}

document.getElementById('refresh-first').addEventListener('click', () => runFirstAnalysis('normal'));
document.getElementById('more-assertive-first').addEventListener('click', () => runFirstAnalysis('assertive'));
document.getElementById('more-soft-first').addEventListener('click', () => runFirstAnalysis('soft'));
document.getElementById('retry-first').addEventListener('click', () => {
  firstError.classList.add('hidden');
  profileUpload.click();
});

// ---------- Continue Flow ----------
const myLastMessage = document.getElementById('my-last-message');
const herReply = document.getElementById('her-reply');
const generateContinueBtn = document.getElementById('generate-continue');
const continueLoading = document.getElementById('continue-loading');
const continueResults = document.getElementById('continue-results');
const continueSuggestions = document.getElementById('continue-suggestions');
const continueError = document.getElementById('continue-error');

function resetContinue() {
  myLastMessage.value = '';
  herReply.value = '';
  generateContinueBtn.disabled = true;
  continueLoading.classList.add('hidden');
  continueResults.classList.add('hidden');
  continueError.classList.add('hidden');
}

function checkContinueReady() {
  const ready = myLastMessage.value.trim().length > 0 || herReply.value.trim().length > 0;
  generateContinueBtn.disabled = !ready;
}

myLastMessage.addEventListener('input', checkContinueReady);
herReply.addEventListener('input', checkContinueReady);

// Image uploads for continue (mock – just show that something was uploaded)
function setupImageUpload(btnId, inputId, textarea) {
  const btn = document.getElementById(btnId);
  const input = document.getElementById(inputId);
  btn.addEventListener('click', () => input.click());
  input.addEventListener('change', () => {
    if (input.files?.[0]) {
      textarea.value = '[Ekran görüntüsü yüklendi – metin çıkarımı simüle edildi]';
      checkContinueReady();
      showToast('Görüntü alındı (demo)');
    }
  });
}

setupImageUpload('upload-my-msg', 'my-msg-upload', myLastMessage);
setupImageUpload('upload-her-reply', 'her-reply-upload', herReply);

function runContinueAnalysis(variant = 'normal') {
  const my = myLastMessage.value.trim();
  const her = herReply.value.trim();
  if (!my && !her) {
    continueError.classList.remove('hidden');
    return;
  }
  continueError.classList.add('hidden');
  continueResults.classList.add('hidden');
  continueLoading.classList.remove('hidden');

  setTimeout(() => {
    continueLoading.classList.add('hidden');
    const data = generateContinueMessages(my, her, variant);
    renderSuggestions(continueSuggestions, data);
    continueResults.classList.remove('hidden');
  }, 1400 + Math.random() * 700);
}

generateContinueBtn.addEventListener('click', () => runContinueAnalysis('normal'));
document.getElementById('refresh-continue').addEventListener('click', () => runContinueAnalysis('normal'));
document.getElementById('more-assertive-continue').addEventListener('click', () => runContinueAnalysis('assertive'));
document.getElementById('more-soft-continue').addEventListener('click', () => runContinueAnalysis('soft'));

// ---------- PWA registration ----------
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('sw.js').catch(() => {});
  });
}
